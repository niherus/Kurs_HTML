#!/usr/bin/perl -w
use strict;
while (<>)
{
	chomp;
	s/^(\d+) (\d+) (\d+) 1 (.*) $/$1 $2 $3 0 $4 1/;
	print $_, "\n";
}

